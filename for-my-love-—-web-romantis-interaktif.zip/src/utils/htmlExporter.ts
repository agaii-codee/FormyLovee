import { RomanticData } from '../types.ts';

export function generateStandaloneHtml(data: RomanticData): string {
  const safeTitle = data.relationshipTitle.replace(/"/g, '&quot;');
  const safePartner = data.partnerName.replace(/"/g, '&quot;');
  const safeSender = data.senderName.replace(/"/g, '&quot;');
  const safeQuote = data.customQuote.replace(/"/g, '&quot;');
  const reasonsJson = JSON.stringify(data.reasons);
  const letterBodyFormatted = data.letterBody.split('\n\n').map(p => `<p class="mb-4">${p.trim()}</p>`).join('');

  return `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${safeTitle} - Untuk ${safePartner}</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Caveat:wght@400..700&family=Playfair+Display:ital,wght@0,400..900;1,400..900&family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      background-color: #0c0a0e;
      color: #f5f0eb;
      font-family: 'Plus Jakarta Sans', sans-serif;
      min-height: 100vh;
      overflow-x: hidden;
      line-height: 1.6;
    }
    .font-serif { font-family: 'Playfair Display', Georgia, serif; }
    .font-handwriting { font-family: 'Caveat', cursive; }
    .tabular-nums { font-variant-numeric: tabular-nums; }
    
    .floating-heart {
      position: fixed;
      pointer-events: none;
      animation: floatUp linear infinite;
      z-index: 1;
      opacity: 0.6;
    }
    @keyframes floatUp {
      0% { transform: translateY(0) scale(0.8) rotate(0deg); opacity: 0; }
      20% { opacity: 0.7; }
      80% { opacity: 0.7; }
      100% { transform: translateY(-110vh) scale(1.2) rotate(360deg); opacity: 0; }
    }

    /* Envelope Opening Overlay */
    #envelope-screen {
      position: fixed;
      inset: 0;
      background: radial-gradient(circle at center, #241426 0%, #0c0a0e 100%);
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      z-index: 9999;
      transition: opacity 0.8s ease, visibility 0.8s;
      padding: 20px;
    }
    .envelope-box {
      width: 320px;
      height: 220px;
      background: #881337;
      border-radius: 12px;
      position: relative;
      cursor: pointer;
      box-shadow: 0 25px 50px -12px rgba(244, 63, 94, 0.25);
      border: 1px solid rgba(251, 113, 133, 0.3);
      display: flex;
      align-items: center;
      justify-content: center;
      transition: transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .envelope-box:hover {
      transform: scale(1.03) translateY(-4px);
    }
    .wax-seal {
      width: 64px;
      height: 64px;
      background: #e11d48;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #ffe4e6;
      box-shadow: 0 4px 14px rgba(0,0,0,0.4);
      border: 2px solid #fda4af;
      font-size: 24px;
    }

    /* Container */
    .container {
      max-width: 960px;
      margin: 0 auto;
      padding: 40px 20px;
      position: relative;
      z-index: 2;
    }
    .card {
      background: rgba(25, 20, 28, 0.7);
      backdrop-filter: blur(16px);
      border: 1px solid rgba(255, 255, 255, 0.08);
      border-radius: 20px;
      padding: 32px;
      margin-bottom: 32px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
    }
    .grid-timer {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 16px;
      margin-top: 24px;
    }
    .timer-tile {
      background: rgba(40, 26, 44, 0.6);
      border: 1px solid rgba(255, 182, 193, 0.15);
      border-radius: 14px;
      padding: 16px;
      text-align: center;
    }
    .timer-val {
      font-size: 2.25rem;
      font-weight: 700;
      color: #fda4af;
      line-height: 1;
    }
    .timer-label {
      font-size: 0.8rem;
      color: #cbd5e1;
      margin-top: 6px;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }

    /* Button styles */
    .btn-romantic {
      background: linear-gradient(135deg, #e11d48, #be123c);
      color: #ffffff;
      padding: 12px 28px;
      border-radius: 9999px;
      border: none;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.2s ease;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      box-shadow: 0 4px 15px rgba(225, 29, 72, 0.35);
    }
    .btn-romantic:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(225, 29, 72, 0.45);
    }
    
    .audio-toggle {
      position: fixed;
      top: 20px;
      right: 20px;
      z-index: 100;
      background: rgba(28, 20, 32, 0.85);
      border: 1px solid rgba(255, 255, 255, 0.15);
      border-radius: 9999px;
      padding: 10px 18px;
      color: #fda4af;
      cursor: pointer;
      backdrop-filter: blur(8px);
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 14px;
    }

    /* Floating runaway button for quiz */
    .runaway-wrap {
      position: relative;
      min-height: 140px;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 20px;
    }
  </style>
</head>
<body>

  <!-- Floating Audio Controller -->
  <button id="audio-btn" class="audio-toggle" onclick="toggleAudio()">
    <span id="audio-icon">🎵</span>
    <span id="audio-text">Putar Musik Romantis</span>
  </button>

  <!-- Envelope Intro Overlay -->
  <div id="envelope-screen">
    <div class="envelope-box" onclick="openLetter()">
      <div class="wax-seal">💌</div>
    </div>
    <h2 class="font-serif" style="font-size: 1.5rem; margin-top: 24px; color: #fda4af;">Sebuah Surat Istimewa</h2>
    <p style="color: #cbd5e1; font-size: 0.95rem; margin-top: 8px;">Klik amplop untuk membuka pesan dari ${safeSender}</p>
  </div>

  <div class="container">
    <!-- Header Hero -->
    <header style="text-align: center; margin-bottom: 48px; padding-top: 24px;">
      <p style="color: #fb7185; letter-spacing: 0.1em; text-transform: uppercase; font-size: 0.85rem; font-weight: 600;">Kisah Kasih Abadi</p>
      <h1 class="font-serif" style="font-size: clamp(2rem, 5vw, 3.25rem); color: #fff; margin: 12px 0;">${safeTitle}</h1>
      <p class="font-handwriting" style="font-size: 1.8rem; color: #fda4af;">${safeQuote}</p>
    </header>

    <!-- Relationship Counter -->
    <section class="card">
      <div style="text-align: center;">
        <p style="color: #fda4af; font-size: 0.9rem; font-weight: 600;">WAKTU BERSAMA</p>
        <h2 class="font-serif" style="font-size: 1.75rem; margin-top: 4px;">Setiap Detik Berarti Bersamamu</h2>
        <p style="color: #94a3b8; font-size: 0.85rem; margin-top: 4px;">Terhitung sejak <span id="start-date-text"></span></p>
      </div>
      <div class="grid-timer">
        <div class="timer-tile"><div id="days" class="timer-val tabular-nums">0</div><div class="timer-label">Hari</div></div>
        <div class="timer-tile"><div id="hours" class="timer-val tabular-nums">00</div><div class="timer-label">Jam</div></div>
        <div class="timer-tile"><div id="minutes" class="timer-val tabular-nums">00</div><div class="timer-label">Menit</div></div>
        <div class="timer-tile"><div id="seconds" class="timer-val tabular-nums">00</div><div class="timer-label">Detik</div></div>
      </div>
    </section>

    <!-- Surat Cinta -->
    <section class="card" style="background: radial-gradient(circle at top, rgba(55, 30, 48, 0.4), rgba(20, 16, 24, 0.8));">
      <div style="border-bottom: 1px solid rgba(255,255,255,0.08); padding-bottom: 16px; margin-bottom: 24px;">
        <span style="font-size: 0.8rem; color: #fb7185;">Surat Dari Hatiku</span>
        <h2 class="font-serif" style="font-size: 1.75rem; color: #fff; margin-top: 4px;">${data.letterHeadline}</h2>
      </div>
      <div style="font-size: 1.05rem; color: #e2e8f0; line-height: 1.8;">
        ${letterBodyFormatted}
      </div>
      <div style="margin-top: 32px; text-align: right; border-top: 1px solid rgba(255,255,255,0.08); padding-top: 16px;">
        <p style="color: #94a3b8; font-size: 0.85rem;">Dengan tulus & cinta sejati,</p>
        <p class="font-handwriting" style="font-size: 2rem; color: #fb7185;">${safeSender}</p>
      </div>
    </section>

    <!-- Interactive Reasons -->
    <section class="card">
      <div style="text-align: center; margin-bottom: 24px;">
        <h2 class="font-serif" style="font-size: 1.75rem;">Kenapa Aku Mencintaimu?</h2>
        <p style="color: #94a3b8; font-size: 0.9rem;">Klik tombol di bawah untuk membuka kartu alasan cinta secara acak</p>
      </div>
      <div id="reason-box" style="background: rgba(45, 28, 48, 0.5); border: 1px dashed rgba(251, 113, 133, 0.4); border-radius: 16px; padding: 24px; text-align: center; min-height: 90px; display: flex; align-items: center; justify-content: center;">
        <p id="reason-text" class="font-serif" style="font-size: 1.15rem; color: #fbcfe8; font-style: italic;">
          "${data.reasons[0]}"
        </p>
      </div>
      <div style="text-align: center; margin-top: 20px;">
        <button class="btn-romantic" onclick="nextReason()">
          <span>Buka Alasan Lainnya ✨</span>
        </button>
      </div>
    </section>

    <!-- Romantic Question -->
    <section class="card" style="text-align: center;">
      <h2 class="font-serif" style="font-size: 1.85rem; color: #fff;">Sebuah Pertanyaan Kecil...</h2>
      <p style="color: #cbd5e1; margin-top: 6px;">Maukah kamu terus menjadi alasan tersenyumku setiap hari, ${safePartner}?</p>
      <div class="runaway-wrap" id="question-arena">
        <button id="btn-yes" class="btn-romantic" style="font-size: 1.1rem; padding: 14px 36px;" onclick="sayYes()">
          Iya, Tentu Saja! ❤️
        </button>
        <button id="btn-no" style="background: rgba(255,255,255,0.08); color: #94a3b8; border: 1px solid rgba(255,255,255,0.15); padding: 10px 24px; border-radius: 9999px; cursor: pointer; transition: transform 0.2s ease;" onmouseenter="runAway(this)" onclick="runAway(this)">
          Nggak Mau 😜
        </button>
      </div>
      <div id="yes-message" style="display: none; margin-top: 20px; padding: 20px; background: rgba(225, 29, 72, 0.15); border-radius: 16px; border: 1px solid #fb7185;">
        <p class="font-handwriting" style="font-size: 2.2rem; color: #fda4af;">Terima kasih telah memilihku! Aku sayang kamu selamanya! 💖</p>
      </div>
    </section>
  </div>

  <script>
    // Audio Synthesizer (Zero external dependencies)
    let audioCtx = null;
    let isPlaying = false;
    let timerId = null;
    const chords = [
      [261.63, 329.63, 392.00, 493.88],
      [220.00, 261.63, 329.63, 392.00],
      [174.61, 220.00, 261.63, 329.63],
      [196.00, 246.94, 293.66, 329.63]
    ];
    let noteIdx = 0;

    function getAudioCtx() {
      if (!audioCtx) {
        audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      }
      if (audioCtx.state === 'suspended') {
        audioCtx.resume();
      }
      return audioCtx;
    }

    function playTone(freq, dur) {
      if (!isPlaying) return;
      try {
        const ctx = getAudioCtx();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, ctx.currentTime);
        gain.gain.setValueAtTime(0.001, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.2, ctx.currentTime + 0.04);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + dur);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + dur + 0.05);
      } catch(e) {}
    }

    function musicLoop() {
      if (!isPlaying) return;
      const cIdx = Math.floor(noteIdx / 4) % chords.length;
      const chord = chords[cIdx];
      const freq = chord[noteIdx % chord.length];
      playTone(freq, 1.2);
      noteIdx++;
      timerId = setTimeout(musicLoop, 360);
    }

    function toggleAudio() {
      if (isPlaying) {
        isPlaying = false;
        clearTimeout(timerId);
        document.getElementById('audio-text').innerText = 'Putar Musik Romantis';
        document.getElementById('audio-icon').innerText = '🎵';
      } else {
        isPlaying = true;
        getAudioCtx();
        musicLoop();
        document.getElementById('audio-text').innerText = 'Jeda Musik';
        document.getElementById('audio-icon').innerText = '⏸️';
      }
    }

    function openLetter() {
      const scr = document.getElementById('envelope-screen');
      scr.style.opacity = '0';
      setTimeout(() => { scr.style.display = 'none'; }, 800);
      if (!isPlaying) {
        toggleAudio();
      }
      createHearts();
    }

    // Relationship timer
    const startDate = new Date("${data.startDate}");
    document.getElementById('start-date-text').innerText = startDate.toLocaleDateString('id-ID', {
      day: 'numeric', month: 'long', year: 'numeric'
    });

    function updateTimer() {
      const now = new Date();
      const diff = now - startDate;
      if (diff > 0) {
        const totalSec = Math.floor(diff / 1000);
        const days = Math.floor(totalSec / 86400);
        const hours = Math.floor((totalSec % 86400) / 3600);
        const mins = Math.floor((totalSec % 3600) / 60);
        const secs = totalSec % 60;
        document.getElementById('days').innerText = days;
        document.getElementById('hours').innerText = String(hours).padStart(2, '0');
        document.getElementById('minutes').innerText = String(mins).padStart(2, '0');
        document.getElementById('seconds').innerText = String(secs).padStart(2, '0');
      }
    }
    setInterval(updateTimer, 1000);
    updateTimer();

    // Love reasons
    const reasons = ${reasonsJson};
    let currentReasonIdx = 0;
    function nextReason() {
      currentReasonIdx = (currentReasonIdx + 1) % reasons.length;
      document.getElementById('reason-text').innerText = '"' + reasons[currentReasonIdx] + '"';
    }

    // Runaway button
    function runAway(btn) {
      const x = Math.random() * 200 - 100;
      const y = Math.random() * 100 - 50;
      btn.style.transform = \`translate(\${x}px, \${y}px)\`;
    }

    function sayYes() {
      document.getElementById('yes-message').style.display = 'block';
      document.getElementById('btn-no').style.display = 'none';
      createHearts();
    }

    // Floating hearts
    function createHearts() {
      const hearts = ['❤️', '💖', '💕', '✨', '🌸', '💐'];
      for (let i = 0; i < 20; i++) {
        setTimeout(() => {
          const el = document.createElement('div');
          el.className = 'floating-heart';
          el.innerText = hearts[Math.floor(Math.random() * hearts.length)];
          el.style.left = Math.random() * 95 + 'vw';
          el.style.bottom = '-20px';
          el.style.fontSize = (Math.random() * 18 + 14) + 'px';
          el.style.animationDuration = (Math.random() * 5 + 4) + 's';
          document.body.appendChild(el);
          setTimeout(() => el.remove(), 9000);
        }, i * 200);
      }
    }
    setInterval(createHearts, 4000);
  </script>
</body>
</html>`;
}

export function getPromptRecommendation(data: RomanticData): string {
  return `Buatkan website romantis interaktif bergaya estetik untuk pasanganku bernama ${data.partnerName} dari ${data.senderName}.
Fitur yang diinginkan:
1. Layar pembuka animasi amplop surat cinta dengan stempel lilin (wax seal) yang bisa diklik.
2. Pemutar musik latar romantis otomatis (melodi lembut piano/music box) dengan kontrol putar/jeda.
3. Penghitung hari jadian otomatis (Relationship Counter) dari tanggal ${data.startDate.split('T')[0]} dengan hitungan Hari, Jam, Menit, Detik.
4. Surat cinta mendalam dan personal dengan judul "${data.letterHeadline}".
5. Kartu interaktif "Alasan Aku Sayang Kamu" yang bisa diklik untuk membuka alasan-alasan manis secara acak.
6. Galeri foto polaroid kenangan manis lengkap dengan caption dan lokasi.
7. Pertanyaan romantis interaktif "Maukah kamu terus bersamaku?" dengan tombol 'Iya' yang memicu confetti cinta dan tombol 'Nggak' yang menghindar saat diarahkan kursor.
8. Desain nuansa malam romantis hangat (deep violet, rose gold, soft parchment) yang responsif untuk HP dan desktop.`;
}
