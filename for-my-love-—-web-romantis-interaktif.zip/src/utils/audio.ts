/**
 * Web Audio API synthesized romantic background music and interactive sound effects.
 * Uses 0 external MP3 dependencies so it works completely offline, instant, and without CORS/broken links.
 */

type AudioStateCallback = (isPlaying: boolean) => void;

class RomanticAudioEngine {
  private ctx: AudioContext | null = null;
  private isPlaying = false;
  private timerId: number | null = null;
  private volumeNode: GainNode | null = null;
  private currentVolume = 0.5;
  private noteIndex = 0;
  private listeners: Set<AudioStateCallback> = new Set();

  // Romantic chord melody notes (Cmaj7, Am9, Fmaj7, G6) in Hz
  private chordProgression: number[][] = [
    // Cmaj7 (C4, E4, G4, B4, D5)
    [261.63, 329.63, 392.00, 493.88, 587.33],
    // Am9 (A3, C4, E4, G4, B4)
    [220.00, 261.63, 329.63, 392.00, 493.88],
    // Fmaj7 (F3, A3, C4, E4, G4)
    [174.61, 220.00, 261.63, 329.63, 392.00],
    // G6 (G3, B3, D4, E4, G4)
    [196.00, 246.94, 293.66, 329.63, 392.00],
  ];

  private notifyListeners() {
    const state = this.isPlaying;
    this.listeners.forEach((cb) => {
      try {
        cb(state);
      } catch {
        // ignore
      }
    });
  }

  public subscribe(cb: AudioStateCallback): () => void {
    this.listeners.add(cb);
    cb(this.isPlaying);
    return () => {
      this.listeners.delete(cb);
    };
  }

  private getContext(): AudioContext {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    return this.ctx;
  }

  public setVolume(val: number) {
    this.currentVolume = Math.max(0, Math.min(1, val));
    if (this.volumeNode && this.ctx) {
      this.volumeNode.gain.setValueAtTime(this.currentVolume, this.ctx.currentTime);
    }
  }

  public toggle(): boolean {
    if (this.isPlaying) {
      this.stop();
      return false;
    } else {
      this.play();
      return true;
    }
  }

  public getIsPlaying(): boolean {
    return this.isPlaying;
  }

  public play() {
    if (this.isPlaying) return;
    try {
      const ctx = this.getContext();
      if (!this.volumeNode) {
        this.volumeNode = ctx.createGain();
        this.volumeNode.connect(ctx.destination);
      }
      this.volumeNode.gain.setValueAtTime(this.currentVolume, ctx.currentTime);

      this.isPlaying = true;
      this.noteIndex = 0;
      this.scheduleLoop();
      this.notifyListeners();
    } catch {
      this.isPlaying = false;
      this.notifyListeners();
    }
  }

  private playTone(freq: number, duration: number, delayMs = 0) {
    if (!this.isPlaying) return;
    try {
      const ctx = this.getContext();
      const startTime = ctx.currentTime + delayMs / 1000;

      // Master tone oscillator (warm sine + gentle triangle harmonic)
      const osc = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gain = ctx.createGain();
      const filter = ctx.createBiquadFilter();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, startTime);

      osc2.type = 'triangle';
      osc2.frequency.setValueAtTime(freq * 2, startTime); // soft octave harmonic

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(1400, startTime);
      filter.frequency.exponentialRampToValueAtTime(400, startTime + duration);

      // Music box bell-like envelope
      gain.gain.setValueAtTime(0.0001, startTime);
      gain.gain.exponentialRampToValueAtTime(0.25, startTime + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);

      osc.connect(filter);
      osc2.connect(filter);
      filter.connect(gain);

      if (this.volumeNode) {
        gain.connect(this.volumeNode);
      } else {
        gain.connect(ctx.destination);
      }

      osc.start(startTime);
      osc2.start(startTime);
      osc.stop(startTime + duration + 0.05);
      osc2.stop(startTime + duration + 0.05);
    } catch {
      // ignore
    }
  }

  private scheduleLoop() {
    if (!this.isPlaying) return;

    const currentChordIndex = Math.floor(this.noteIndex / 8) % this.chordProgression.length;
    const chord = this.chordProgression[currentChordIndex];
    
    // Arpeggiate chord notes with gentle variation
    const noteInStep = this.noteIndex % 8;
    const noteFreq = chord[noteInStep % chord.length];

    this.playTone(noteFreq, 1.4);

    // Subtle bass note on 1st beat of each measure
    if (noteInStep === 0) {
      this.playTone(chord[0] / 2, 2.5);
    }

    this.noteIndex++;
    // 340ms per step (~94 BPM dreamy arpeggio)
    this.timerId = window.setTimeout(() => this.scheduleLoop(), 340);
  }

  public stop() {
    this.isPlaying = false;
    if (this.timerId) {
      window.clearTimeout(this.timerId);
      this.timerId = null;
    }
    this.notifyListeners();
  }

  // Romantic Sound Effects
  public playHeartChime() {
    try {
      const ctx = this.getContext();
      const now = ctx.currentTime;
      const notes = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6
      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + idx * 0.08);

        gain.gain.setValueAtTime(0, now + idx * 0.08);
        gain.gain.linearRampToValueAtTime(0.18, now + idx * 0.08 + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.08 + 0.6);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now + idx * 0.08);
        osc.stop(now + idx * 0.08 + 0.7);
      });
    } catch {
      // ignore
    }
  }

  public playCelebrationFanfare() {
    try {
      const ctx = this.getContext();
      const now = ctx.currentTime;
      const notes = [523.25, 659.25, 783.99, 1046.50, 1318.51];
      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, now + idx * 0.1);

        gain.gain.setValueAtTime(0, now + idx * 0.1);
        gain.gain.linearRampToValueAtTime(0.25, now + idx * 0.1 + 0.03);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + idx * 0.1 + 0.8);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now + idx * 0.1);
        osc.stop(now + idx * 0.1 + 0.9);
      });
    } catch {
      // ignore
    }
  }
}

export const romanticAudio = new RomanticAudioEngine();
