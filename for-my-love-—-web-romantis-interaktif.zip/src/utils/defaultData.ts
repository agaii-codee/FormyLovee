import { RomanticData } from '../types.ts';

export const DEFAULT_ROMANTIC_DATA: RomanticData = {
  partnerName: 'Adinda Cantik',
  senderName: 'Kekasih Hatimu',
  startDate: '2024-02-14T00:00:00',
  relationshipTitle: 'Perjalanan Kisah Indah Kita',
  letterHeadline: 'Untuk Kamu, yang Mengisi Separuh Jiwaku',
  letterBody: `Hari ini, saat aku menuliskan setiap kata ini, hatiku dipenuhi dengan rasa syukur yang begitu mendalam. Mengenalmu adalah salah satu hadiah terindah yang pernah Tuhan titipkan dalam hidupku.

Kamu adalah senja yang menenangkan setelah hari yang melelahkan. Kamu adalah pelangi yang selalu hadir membawa warna di saat langit hatiku mendung. Setiap senyumanmu, setiap tawa renyahmu, dan bahkan tatapan matamu yang teduh selalu berhasil membuat dunia yang bising ini terasa begitu damai.

Terima kasih telah memilih untuk melangkah bersamaku, menggenggam tanganku melewati hari-hari yang manis maupun saat ujian datang. Aku berjanji akan terus berusaha menjadi tempatmu bersandar, orang pertama yang memelukmu saat rapuh, dan orang yang paling antusias merayakan setiap bahagiamu.

Selamat merayakan setiap detik kebersamaan kita. Aku mencintaimu hari ini, esok, dan di setiap lembar kisah kita selanjutnya.`,
  customQuote: '“Jika aku harus mengulang hidupku dari awal, aku hanya ingin satu hal: menemukanmu lebih cepat agar bisa mencintaimu lebih lama.”',
  reasons: [
    'Senyum manismu yang selalu berhasil mencairkan rasa lelahku setelah seharian beraktivitas.',
    'Caramu tertawa lepas saat mendengarkan cerita receh atau candaan konyolku.',
    'Kebaikan hatimu yang begitu tulus saat memperlakukan orang-orang di sekitarmu.',
    'Tatapan matamu yang hangat, membuatku selalu merasa berada di rumah.',
    'Dukungan tanpa henti yang kamu berikan di setiap langkah dan mimpi kecilku.',
    'Kehangatan genggaman tanganmu setiap kali kita berjalan berdampingan.',
    'Kamu yang selalu sabar memahami kekuranganku dan menjadikanku versi yang lebih baik.',
    'Hal-hal kecil tentangmu: aroma parfummu, caramu merapikan rambut, dan perhatian tulusmu.',
  ],
  memories: [
    {
      id: 'mem-1',
      title: 'Kecupan Manis Penuh Cinta',
      date: '27 Oktober 2026',
      imageUrl: '/assets/aistudio/IMG-20260905-WA0038_40c95b50.jpg',
      caption: "Jujur, hari itu aku susah fokus karena terlalu sibuk kagum ngeliat kamu. You look so gorgeous tonight, seriously. Pemandangan di sekeliling kita langsung kalah jauh sama kecantikan kamu yang duduk di samping aku. I'm truly the luckiest person to have you.",
      location: "King's Shopping Centre"
    },
    {
      id: 'mem-2',
      title: 'Segelas Matcha & Cerita Kita',
      date: '19 Maret 2026',
      imageUrl: '/assets/aistudio/IMG_20260319_175741_258_9b2ae6df.jpg',
      caption: 'Dua hari sebelum Lebaran kemarin rasanya spesial banget cuma karena ada kamu. Pas kamu lagi minum matcha malam itu, aku sadar satu hal: rasa manis di gelas itu nggak ada apa apanya dibanding manisnya momen saat aku bisa natap mata kamu secara langsung.',
      location: 'Kolato'
    },
    {
      id: 'mem-3',
      title: 'Aku Kamu dan Braga',
      date: '15 April 2026',
      imageUrl: '/assets/aistudio/IMG_20260415_201447_6_f132cbf2.jpg',
      caption: "Malam itu di Jalan Braga, kamu mungkin fokus sama jalanan dan suasana di sekitar kita. But to be honest, my eyes were only on you. Berjalan di samping kamu bikin aku sadar satu hal whenever I'm with you, I always wish time would just slow down. Momen malam itu terasa terlalu cepat, padahal aku cuma pengen bisa berdua lebih lama lagi sama kamu.",
      location: 'Jalan Braga'
    }
  ],
  songTitle: 'Melodi Kisah Kasih (Music Box Edition)'
};

const STORAGE_KEY = 'kisah_kasih_romantic_data_v6';

export function loadSavedRomanticData(): RomanticData {
  try {
    // 1. Check URL parameters first (allows sharing custom URLs)
    const urlParams = new URLSearchParams(window.location.search);
    const encodedPayload = urlParams.get('d');
    if (encodedPayload) {
      const decoded = decodeURIComponent(atob(encodedPayload));
      const parsed = JSON.parse(decoded);
      return { ...DEFAULT_ROMANTIC_DATA, ...parsed };
    }

    // 2. Check simple query params: ?to=Nama&from=Nama&date=YYYY-MM-DD
    const toParam = urlParams.get('to');
    const fromParam = urlParams.get('from');
    const dateParam = urlParams.get('date');
    if (toParam || fromParam || dateParam) {
      return {
        ...DEFAULT_ROMANTIC_DATA,
        partnerName: toParam || DEFAULT_ROMANTIC_DATA.partnerName,
        senderName: fromParam || DEFAULT_ROMANTIC_DATA.senderName,
        startDate: dateParam ? `${dateParam}T00:00:00` : DEFAULT_ROMANTIC_DATA.startDate,
      };
    }

    // 3. Check localStorage
    const saved = localStorage.getItem(STORAGE_KEY) || localStorage.getItem('kisah_kasih_romantic_data_v3') || localStorage.getItem('kisah_kasih_romantic_data_v2') || localStorage.getItem('kisah_kasih_romantic_data_v1');
    if (saved) {
      const parsed = JSON.parse(saved);
      // Migrate memories with latest user photos, dates, locations and captions
      if (Array.isArray(parsed.memories)) {
        parsed.memories = parsed.memories.map((m: MemoryItem) => {
          if (m.id === 'mem-1' || (m.imageUrl && m.imageUrl.includes('romantic_polaroid_sunset'))) {
            return {
              ...m,
              id: 'mem-1',
              title: 'Kecupan Manis Penuh Cinta',
              date: '27 Oktober 2026',
              imageUrl: '/assets/aistudio/IMG-20260905-WA0038_40c95b50.jpg',
              caption: "Jujur, hari itu aku susah fokus karena terlalu sibuk kagum ngeliat kamu. You look so gorgeous tonight, seriously. Pemandangan di sekeliling kita langsung kalah jauh sama kecantikan kamu yang duduk di samping aku. I'm truly the luckiest person to have you.",
              location: "King's Shopping Centre"
            };
          }
          if (m.id === 'mem-2' || (m.imageUrl && m.imageUrl.includes('romantic_polaroid_coffee'))) {
            return {
              ...m,
              id: 'mem-2',
              title: 'Segelas Matcha & Cerita Kita',
              date: '19 Maret 2026',
              imageUrl: '/assets/aistudio/IMG_20260319_175741_258_9b2ae6df.jpg',
              caption: 'Dua hari sebelum Lebaran kemarin rasanya spesial banget cuma karena ada kamu. Pas kamu lagi minum matcha malam itu, aku sadar satu hal: rasa manis di gelas itu nggak ada apa apanya dibanding manisnya momen saat aku bisa natap mata kamu secara langsung.',
              location: 'Kolato'
            };
          }
          if (m.id === 'mem-3' || (m.imageUrl && m.imageUrl.includes('romantic_starlit_night'))) {
            return {
              ...m,
              id: 'mem-3',
              title: 'Aku Kamu dan Braga',
              date: '15 April 2026',
              imageUrl: '/assets/aistudio/IMG_20260415_201447_6_f132cbf2.jpg',
              caption: "Malam itu di Jalan Braga, kamu mungkin fokus sama jalanan dan suasana di sekitar kita. But to be honest, my eyes were only on you. Berjalan di samping kamu bikin aku sadar satu hal whenever I'm with you, I always wish time would just slow down. Momen malam itu terasa terlalu cepat, padahal aku cuma pengen bisa berdua lebih lama lagi sama kamu.",
              location: 'Jalan Braga'
            };
          }
          return m;
        });
      }
      return { ...DEFAULT_ROMANTIC_DATA, ...parsed, songTitle: 'Melodi Kisah Kasih (Music Box Edition)' };
    }
  } catch {
    // fallback to defaults on parse error
  }
  return DEFAULT_ROMANTIC_DATA;
}

export function saveRomanticData(data: RomanticData): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch {
    // ignore
  }
}

export function generateShareUrl(data: RomanticData): string {
  const minimalData = {
    partnerName: data.partnerName,
    senderName: data.senderName,
    startDate: data.startDate,
    relationshipTitle: data.relationshipTitle,
    letterHeadline: data.letterHeadline,
    letterBody: data.letterBody,
    customQuote: data.customQuote,
    reasons: data.reasons,
  };
  try {
    const encoded = btoa(encodeURIComponent(JSON.stringify(minimalData)));
    const baseUrl = window.location.origin + window.location.pathname;
    return `${baseUrl}?d=${encoded}`;
  } catch {
    return window.location.href;
  }
}
