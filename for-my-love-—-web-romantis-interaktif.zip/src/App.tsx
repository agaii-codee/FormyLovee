import { useState, useEffect } from 'react';
import { FloatingHearts } from './components/FloatingHearts.tsx';
import { HeaderNav } from './components/HeaderNav.tsx';
import { EnvelopeIntro } from './components/EnvelopeIntro.tsx';
import { RelationshipTimer } from './components/RelationshipTimer.tsx';
import { LoveLetter } from './components/LoveLetter.tsx';
import { MemoriesGallery } from './components/MemoriesGallery.tsx';
import { LoveReasonsJar } from './components/LoveReasonsJar.tsx';
import { RomanticProposal } from './components/RomanticProposal.tsx';
import { MusicPlayerBar } from './components/MusicPlayerBar.tsx';
import { CustomizeModal } from './components/CustomizeModal.tsx';
import { ExportShareModal } from './components/ExportShareModal.tsx';
import { loadSavedRomanticData, saveRomanticData } from './utils/defaultData.ts';
import { RomanticData, MemoryItem } from './types.ts';
import { Sparkles, MailOpen } from 'lucide-react';
import { romanticAudio } from './utils/audio.ts';

export default function App() {
  const [romanticData, setRomanticData] = useState<RomanticData>(loadSavedRomanticData);
  const [showEnvelope, setShowEnvelope] = useState(true);
  const [isCustomizeOpen, setIsCustomizeOpen] = useState(false);
  const [isExportOpen, setIsExportOpen] = useState(false);

  useEffect(() => {
    // Ensure memories have the latest customized photos, captions and locations
    const mem1 = romanticData.memories.find(m => m.id === 'mem-1');
    const targetCaption1 = "Jujur, hari itu aku susah fokus karena terlalu sibuk kagum ngeliat kamu. You look so gorgeous tonight, seriously. Pemandangan di sekeliling kita langsung kalah jauh sama kecantikan kamu yang duduk di samping aku. I'm truly the luckiest person to have you.";
    
    const mem2 = romanticData.memories.find(m => m.id === 'mem-2');
    const targetCaption2 = "Dua hari sebelum Lebaran kemarin rasanya spesial banget cuma karena ada kamu. Pas kamu lagi minum matcha malam itu, aku sadar satu hal: rasa manis di gelas itu nggak ada apa apanya dibanding manisnya momen saat aku bisa natap mata kamu secara langsung.";

    const mem3 = romanticData.memories.find(m => m.id === 'mem-3');
    const targetCaption3 = "Malam itu di Jalan Braga, kamu mungkin fokus sama jalanan dan suasana di sekitar kita. But to be honest, my eyes were only on you. Berjalan di samping kamu bikin aku sadar satu hal whenever I'm with you, I always wish time would just slow down. Momen malam itu terasa terlalu cepat, padahal aku cuma pengen bisa berdua lebih lama lagi sama kamu.";

    let needsUpdate = false;
    if (mem1 && (mem1.caption !== targetCaption1 || mem1.location !== "King's Shopping Centre")) {
      needsUpdate = true;
    }
    if (mem2 && (mem2.caption !== targetCaption2 || mem2.location !== "Kolato" || mem2.title !== "Segelas Matcha & Cerita Kita")) {
      needsUpdate = true;
    }
    if (mem3 && (mem3.caption !== targetCaption3 || mem3.location !== "Jalan Braga" || mem3.title !== "Aku Kamu dan Braga")) {
      needsUpdate = true;
    }
    if (romanticData.songTitle !== 'Melodi Kisah Kasih (Music Box Edition)') {
      needsUpdate = true;
    }

    if (needsUpdate) {
      const updatedMemories = romanticData.memories.map(m => {
        if (m.id === 'mem-1') {
          return {
            ...m,
            date: '27 Oktober 2026',
            location: "King's Shopping Centre",
            caption: targetCaption1,
            imageUrl: '/assets/aistudio/IMG-20260905-WA0038_40c95b50.jpg',
          };
        }
        if (m.id === 'mem-2') {
          return {
            ...m,
            title: 'Segelas Matcha & Cerita Kita',
            date: '19 Maret 2026',
            location: 'Kolato',
            caption: targetCaption2,
            imageUrl: '/assets/aistudio/IMG_20260319_175741_258_9b2ae6df.jpg',
          };
        }
        if (m.id === 'mem-3') {
          return {
            ...m,
            title: 'Aku Kamu dan Braga',
            date: '15 April 2026',
            location: 'Jalan Braga',
            caption: targetCaption3,
            imageUrl: '/assets/aistudio/IMG_20260415_201447_6_f132cbf2.jpg',
          };
        }
        return m;
      });
      const updated = { ...romanticData, memories: updatedMemories, songTitle: 'Melodi Kisah Kasih (Music Box Edition)' };
      setRomanticData(updated);
      saveRomanticData(updated);
    }
  }, []);

  const handleUpdateData = (newData: RomanticData) => {
    setRomanticData(newData);
    saveRomanticData(newData);
  };

  const handleAddMemory = (item: MemoryItem) => {
    const updated = {
      ...romanticData,
      memories: [item, ...romanticData.memories],
    };
    handleUpdateData(updated);
  };

  const handleRemoveMemory = (id: string) => {
    const updated = {
      ...romanticData,
      memories: romanticData.memories.filter(m => m.id !== id),
    };
    handleUpdateData(updated);
  };

  const handleReopenEnvelope = () => {
    romanticAudio.playHeartChime();
    setShowEnvelope(true);
  };

  return (
    <div id="top" className="min-h-screen bg-[#0c0a0e] text-stone-100 relative selection:bg-rose-500/30 selection:text-rose-200">
      {/* Ambient Rising Hearts */}
      <FloatingHearts />

      {/* Opening Envelope Screen */}
      {showEnvelope && (
        <EnvelopeIntro
          partnerName={romanticData.partnerName}
          senderName={romanticData.senderName}
          onOpen={() => setShowEnvelope(false)}
        />
      )}

      {/* Top Bar Navigation (Strict 3-zone contract) */}
      <HeaderNav
        onOpenCustomize={() => setIsCustomizeOpen(true)}
        onOpenExport={() => setIsExportOpen(true)}
      />

      {/* Main Content Container */}
      <main className="max-w-5xl mx-auto px-5 sm:px-8 py-10 sm:py-16 space-y-16 sm:space-y-24 relative z-10">
        
        {/* Hero Section */}
        <section className="text-center pt-4 sm:pt-10">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-rose-950/50 border border-rose-800/40 text-xs font-medium text-rose-300 mb-5">
            <Sparkles className="w-3.5 h-3.5 text-rose-400" />
            <span>Kisah Kasih Abadi</span>
          </div>

          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-serif-romantic text-white font-normal tracking-tight leading-tight max-w-3xl mx-auto">
            {romanticData.relationshipTitle}
          </h1>

          <p className="font-handwriting text-2xl sm:text-3xl text-rose-300 mt-4 max-w-2xl mx-auto leading-relaxed">
            {romanticData.customQuote}
          </p>

          <div className="flex flex-wrap items-center justify-center gap-3.5 mt-8">
            <button
              onClick={handleReopenEnvelope}
              className="px-5 py-2.5 rounded-full text-xs font-semibold bg-rose-950/70 hover:bg-rose-900 border border-rose-800/50 text-rose-200 transition-colors flex items-center gap-2 cursor-pointer"
            >
              <MailOpen className="w-4 h-4 text-rose-400" />
              <span>Buka Amplop Intro</span>
            </button>

            <button
              onClick={() => setIsExportOpen(true)}
              className="px-6 py-2.5 rounded-full text-xs font-semibold bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-500 hover:to-pink-500 text-white shadow-lg shadow-rose-950/60 transition-all flex items-center gap-2 cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-amber-200" />
              <span>Dapatkan Kode HTML & Prompt</span>
            </button>
          </div>
        </section>

        {/* 1. Relationship Counter */}
        <RelationshipTimer
          startDate={romanticData.startDate}
          partnerName={romanticData.partnerName}
        />

        {/* 2. Surat Cinta Interaktif */}
        <LoveLetter
          headline={romanticData.letterHeadline}
          body={romanticData.letterBody}
          senderName={romanticData.senderName}
          partnerName={romanticData.partnerName}
        />

        {/* 3. Galeri Foto Kenangan Polaroid */}
        <MemoriesGallery
          memories={romanticData.memories}
          onAddMemory={handleAddMemory}
          onRemoveMemory={handleRemoveMemory}
        />

        {/* 4. Toples Alasan Cinta */}
        <LoveReasonsJar
          reasons={romanticData.reasons}
          partnerName={romanticData.partnerName}
        />

        {/* 5. Pertanyaan Romantis Interaktif (Yes/No Runaway button) */}
        <RomanticProposal
          partnerName={romanticData.partnerName}
          senderName={romanticData.senderName}
        />

      </main>

      {/* Quiet Footer */}
      <footer className="mt-20 border-t border-rose-950/50 py-10 text-center text-xs text-stone-500">
        <p className="mb-2 text-stone-400">
          Dirajut dengan penuh cinta untuk <span className="text-rose-300 font-medium">{romanticData.partnerName}</span> dari <span className="text-rose-300 font-medium">{romanticData.senderName}</span>
        </p>
        <p className="text-stone-500">
          Kisah Kasih &copy; {new Date().getFullYear()} &middot; Setiap detik cinta adalah anugerah abadi.
        </p>
      </footer>

      {/* Floating Audio Controller */}
      <MusicPlayerBar songTitle={romanticData.songTitle} />

      {/* Customization Modal */}
      <CustomizeModal
        data={romanticData}
        isOpen={isCustomizeOpen}
        onClose={() => setIsCustomizeOpen(false)}
        onSave={handleUpdateData}
      />

      {/* Export / Share HTML Code & Prompt Modal */}
      <ExportShareModal
        data={romanticData}
        isOpen={isExportOpen}
        onClose={() => setIsExportOpen(false)}
      />
    </div>
  );
}
