import React, { useState } from 'react';
import { X, Copy, Check, Download, Share2, Sparkles, Code2, MessageSquareHeart } from 'lucide-react';
import { RomanticData } from '../types.ts';
import { generateStandaloneHtml, getPromptRecommendation } from '../utils/htmlExporter.ts';
import { generateShareUrl } from '../utils/defaultData.ts';

interface ExportShareModalProps {
  data: RomanticData;
  isOpen: boolean;
  onClose: () => void;
}

export const ExportShareModal: React.FC<ExportShareModalProps> = ({
  data,
  isOpen,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'html' | 'prompt' | 'link'>('html');
  const [copiedType, setCopiedType] = useState<string | null>(null);

  if (!isOpen) return null;

  const standaloneHtml = generateStandaloneHtml(data);
  const promptText = getPromptRecommendation(data);
  const shareUrl = generateShareUrl(data);

  const handleCopy = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    setCopiedType(type);
    setTimeout(() => setCopiedType(null), 2000);
  };

  const handleDownloadHtml = () => {
    const blob = new Blob([standaloneHtml], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `surat-cinta-${data.partnerName.toLowerCase().replace(/\s+/g, '-')}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
      <div className="relative max-w-3xl w-full max-h-[92vh] flex flex-col bg-[#17111c] border border-rose-900/40 rounded-3xl shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between p-6 pb-4 border-b border-stone-800">
          <div>
            <span className="text-xs font-semibold text-rose-300 uppercase tracking-wider">
              Ekspor & Bagikan
            </span>
            <h2 className="text-xl sm:text-2xl font-serif-romantic text-white">
              Kode HTML & Prompt Web Romantis
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-stone-400 hover:text-white rounded-full bg-stone-900/60 hover:bg-stone-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Controls (Functional Segmented Control) */}
        <div className="px-6 pt-4 pb-2 border-b border-stone-800 flex items-center gap-2">
          <button
            onClick={() => setActiveTab('html')}
            className={`px-4 py-2 text-xs font-medium rounded-xl transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'html'
                ? 'bg-rose-950/90 text-rose-200 border border-rose-800/60 shadow-sm'
                : 'text-stone-400 hover:text-stone-200 hover:bg-stone-900'
            }`}
          >
            <Code2 className="w-3.5 h-3.5 text-rose-400" />
            <span>Kode HTML Mandiri (Single-File)</span>
          </button>

          <button
            onClick={() => setActiveTab('prompt')}
            className={`px-4 py-2 text-xs font-medium rounded-xl transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'prompt'
                ? 'bg-rose-950/90 text-rose-200 border border-rose-800/60 shadow-sm'
                : 'text-stone-400 hover:text-stone-200 hover:bg-stone-900'
            }`}
          >
            <MessageSquareHeart className="w-3.5 h-3.5 text-rose-400" />
            <span>Prompt AI</span>
          </button>

          <button
            onClick={() => setActiveTab('link')}
            className={`px-4 py-2 text-xs font-medium rounded-xl transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'link'
                ? 'bg-rose-950/90 text-rose-200 border border-rose-800/60 shadow-sm'
                : 'text-stone-400 hover:text-stone-200 hover:bg-stone-900'
            }`}
          >
            <Share2 className="w-3.5 h-3.5 text-rose-400" />
            <span>Tautan Langsung</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 flex-1 overflow-y-auto">
          {activeTab === 'html' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-rose-950/30 border border-rose-900/30 p-3.5 rounded-2xl">
                <p className="text-xs text-rose-200">
                  File HTML ini 100% mandiri (sudah termasuk animasi hati, penghitung waktu, dan melodi musik). Bisa langsung dibuka di browser atau dikirim lewat WhatsApp.
                </p>
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => handleCopy(standaloneHtml, 'html')}
                    className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    {copiedType === 'html' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedType === 'html' ? 'Tersalin!' : 'Salin Kode'}</span>
                  </button>
                  <button
                    onClick={handleDownloadHtml}
                    className="px-3.5 py-1.5 bg-stone-800 hover:bg-stone-700 text-stone-200 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5 text-rose-400" />
                    <span>Download .html</span>
                  </button>
                </div>
              </div>

              <div className="relative rounded-2xl bg-stone-950 border border-stone-800 p-4">
                <pre className="text-[11px] font-mono text-stone-300 overflow-x-auto max-h-72 leading-relaxed selection:bg-rose-900">
                  {standaloneHtml.slice(0, 3000)}...
                </pre>
                <div className="absolute inset-x-0 bottom-0 h-16 bg-gradient-to-t from-stone-950 to-transparent pointer-events-none rounded-b-2xl" />
              </div>
            </div>
          )}

          {activeTab === 'prompt' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-stone-900/60 border border-stone-800 p-3.5 rounded-2xl">
                <p className="text-xs text-stone-300">
                  Gunakan prompt ini jika ingin membuat variasi website romantis lain dengan instruksi yang rapi dan terstruktur.
                </p>
                <button
                  onClick={() => handleCopy(promptText, 'prompt')}
                  className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer self-start sm:self-auto shrink-0"
                >
                  {copiedType === 'prompt' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedType === 'prompt' ? 'Tersalin!' : 'Salin Prompt'}</span>
                </button>
              </div>

              <div className="rounded-2xl bg-stone-950 border border-stone-800 p-4">
                <textarea
                  readOnly
                  rows={8}
                  value={promptText}
                  className="w-full bg-transparent text-xs text-stone-200 font-sans leading-relaxed focus:outline-none resize-none"
                />
              </div>
            </div>
          )}

          {activeTab === 'link' && (
            <div className="space-y-4">
              <p className="text-xs text-stone-300">
                Kirim link ini langsung ke pasanganmu. Semua nama, pesan cinta, dan tanggal jadian yang kamu edit sudah tersimpan di dalam tautan:
              </p>

              <div className="flex items-center gap-2 bg-stone-950 border border-stone-800 rounded-xl p-2.5">
                <input
                  type="text"
                  readOnly
                  value={shareUrl}
                  className="flex-1 bg-transparent text-xs text-rose-300 font-mono focus:outline-none select-all truncate"
                />
                <button
                  onClick={() => handleCopy(shareUrl, 'link')}
                  className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shrink-0"
                >
                  {copiedType === 'link' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedType === 'link' ? 'Tersalin!' : 'Salin Link'}</span>
                </button>
              </div>

              <div className="p-4 rounded-2xl bg-stone-900/40 border border-stone-800 text-xs text-stone-400">
                <p className="flex items-center gap-1.5 text-rose-300 font-medium mb-1">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Tips Mengirimkan ke Pasangan</span>
                </p>
                <p>
                  Kamu bisa mengirimkan link ini lewat WhatsApp, Instagram DM, atau menjadikannya scan kode QR kejutan pada kado fisik/surat fisik!
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 px-6 border-t border-stone-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-stone-800 hover:bg-stone-700 text-stone-200 rounded-xl text-xs font-medium transition-colors cursor-pointer"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
