import React from 'react';
import { SlidersHorizontal } from 'lucide-react';

interface HeaderNavProps {
  onOpenCustomize: () => void;
  onOpenExport: () => void;
}

export const HeaderNav: React.FC<HeaderNavProps> = ({ onOpenCustomize, onOpenExport }) => {
  return (
    <header className="sticky top-0 z-40 bg-[#0c0a0e]/85 backdrop-blur-md border-b border-rose-950/40">
      <div className="max-w-6xl mx-auto flex items-center justify-between gap-8 px-6 py-4">
        {/* Zone 1: Single text element wordmark */}
        <a href="#top" className="text-xl font-bold tracking-tight text-rose-100 font-serif-romantic whitespace-nowrap shrink-0 hover:text-rose-300 transition-colors">
          Kisah Kasih
        </a>

        {/* Zone 2: 4 clean single-line text navigation links */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-rose-200/80">
          <a href="#perjalanan" className="hover:text-rose-200 hover:underline underline-offset-8 transition-colors whitespace-nowrap shrink-0">
            Perjalanan Kita
          </a>
          <a href="#surat" className="hover:text-rose-200 hover:underline underline-offset-8 transition-colors whitespace-nowrap shrink-0">
            Surat Cinta
          </a>
          <a href="#kenangan" className="hover:text-rose-200 hover:underline underline-offset-8 transition-colors whitespace-nowrap shrink-0">
            Galeri Kenangan
          </a>
          <a href="#alasan" className="hover:text-rose-200 hover:underline underline-offset-8 transition-colors whitespace-nowrap shrink-0">
            Alasan Sayang
          </a>
          <a href="#pertanyaan" className="hover:text-rose-200 hover:underline underline-offset-8 transition-colors whitespace-nowrap shrink-0">
            Sebuah Janji
          </a>
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-2.5 shrink-0">
          <button
            onClick={onOpenCustomize}
            title="Edit Nama, Tanggal, & Isi Surat"
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-rose-300 hover:text-rose-100 hover:bg-rose-950/50 rounded-lg transition-colors whitespace-nowrap shrink-0 border border-rose-900/40 cursor-pointer"
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>Kustomisasi</span>
          </button>
          <button
            onClick={onOpenExport}
            className="px-4 py-2 text-xs font-semibold text-white bg-gradient-to-r from-rose-600 to-pink-600 rounded-lg hover:from-rose-500 hover:to-pink-500 transition-all shadow-md shadow-rose-950/50 whitespace-nowrap shrink-0 cursor-pointer"
          >
            Salin Kode HTML
          </button>
        </div>
      </div>
    </header>
  );
};
