import React, { useState } from 'react';
import { X, Sparkles, RotateCcw, Plus, Trash2 } from 'lucide-react';
import { RomanticData } from '../types.ts';
import { DEFAULT_ROMANTIC_DATA } from '../utils/defaultData.ts';

interface CustomizeModalProps {
  data: RomanticData;
  isOpen: boolean;
  onClose: () => void;
  onSave: (newData: RomanticData) => void;
}

export const CustomizeModal: React.FC<CustomizeModalProps> = ({
  data,
  isOpen,
  onClose,
  onSave,
}) => {
  const [formData, setFormData] = useState<RomanticData>(data);
  const [newReasonInput, setNewReasonInput] = useState('');

  if (!isOpen) return null;

  const handleAddReason = () => {
    if (!newReasonInput.trim()) return;
    setFormData((prev) => ({
      ...prev,
      reasons: [...prev.reasons, newReasonInput.trim()],
    }));
    setNewReasonInput('');
  };

  const handleRemoveReason = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      reasons: prev.reasons.filter((_, i) => i !== index),
    }));
  };

  const handleResetDefaults = () => {
    if (window.confirm('Kembalikan ke template awal?')) {
      setFormData(DEFAULT_ROMANTIC_DATA);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
      <div className="relative max-w-2xl w-full max-h-[90vh] overflow-y-auto bg-[#18111e] border border-rose-900/40 rounded-3xl p-6 sm:p-8 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-stone-800">
          <div>
            <span className="text-xs font-semibold text-rose-300 uppercase tracking-wider">
              Personalisasi Web
            </span>
            <h2 className="text-xl sm:text-2xl font-serif-romantic text-white">
              Edit Data Kisah Kasih Kalian
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-stone-400 hover:text-white rounded-full bg-stone-900/60 hover:bg-stone-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-6 space-y-5 text-xs sm:text-sm">
          {/* Couple Names */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-stone-300 font-medium mb-1">
                Nama Pasangan / Panggilan Sayang
              </label>
              <input
                type="text"
                required
                value={formData.partnerName}
                onChange={(e) => setFormData({ ...formData, partnerName: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-xl bg-stone-900 border border-stone-800 text-stone-100 focus:border-rose-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-stone-300 font-medium mb-1">
                Nama Kamu (Pengirim)
              </label>
              <input
                type="text"
                required
                value={formData.senderName}
                onChange={(e) => setFormData({ ...formData, senderName: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-xl bg-stone-900 border border-stone-800 text-stone-100 focus:border-rose-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Date & Title */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-stone-300 font-medium mb-1">
                Tanggal Jadian / Hari Pertama Bertemu
              </label>
              <input
                type="date"
                required
                value={formData.startDate.split('T')[0]}
                onChange={(e) => setFormData({ ...formData, startDate: `${e.target.value}T00:00:00` })}
                className="w-full px-3.5 py-2.5 rounded-xl bg-stone-900 border border-stone-800 text-stone-100 focus:border-rose-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-stone-300 font-medium mb-1">
                Judul Utama Website
              </label>
              <input
                type="text"
                required
                value={formData.relationshipTitle}
                onChange={(e) => setFormData({ ...formData, relationshipTitle: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-xl bg-stone-900 border border-stone-800 text-stone-100 focus:border-rose-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Quote */}
          <div>
            <label className="block text-stone-300 font-medium mb-1">
              Kutipan / Kalimat Manis Pembuka
            </label>
            <input
              type="text"
              value={formData.customQuote}
              onChange={(e) => setFormData({ ...formData, customQuote: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl bg-stone-900 border border-stone-800 text-stone-100 focus:border-rose-500 focus:outline-none"
            />
          </div>

          {/* Letter Headline & Body */}
          <div>
            <label className="block text-stone-300 font-medium mb-1">
              Judul Surat Cinta
            </label>
            <input
              type="text"
              required
              value={formData.letterHeadline}
              onChange={(e) => setFormData({ ...formData, letterHeadline: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl bg-stone-900 border border-stone-800 text-stone-100 focus:border-rose-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-stone-300 font-medium mb-1">
              Isi Surat Cinta (Gunakan 2x Enter untuk paragraf baru)
            </label>
            <textarea
              rows={6}
              required
              value={formData.letterBody}
              onChange={(e) => setFormData({ ...formData, letterBody: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl bg-stone-900 border border-stone-800 text-stone-100 focus:border-rose-500 focus:outline-none"
            />
          </div>

          {/* Reasons List */}
          <div>
            <label className="block text-stone-300 font-medium mb-2">
              Daftar Alasan Mencintaimu ({formData.reasons.length} Alasan)
            </label>
            <div className="space-y-2 max-h-48 overflow-y-auto pr-1 mb-3">
              {formData.reasons.map((reason, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between gap-2 p-2.5 rounded-lg bg-stone-900/80 border border-stone-800 text-xs"
                >
                  <span className="text-stone-300 truncate flex-1">{reason}</span>
                  <button
                    type="button"
                    onClick={() => handleRemoveReason(index)}
                    className="p-1 text-stone-400 hover:text-rose-400 transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>

            <div className="flex gap-2">
              <input
                type="text"
                placeholder="Tambah alasan baru..."
                value={newReasonInput}
                onChange={(e) => setNewReasonInput(e.target.value)}
                className="flex-1 px-3 py-2 rounded-xl bg-stone-900 border border-stone-800 text-stone-100 text-xs focus:border-rose-500 focus:outline-none"
              />
              <button
                type="button"
                onClick={handleAddReason}
                className="px-4 py-2 bg-stone-800 hover:bg-stone-700 text-rose-300 rounded-xl text-xs font-medium flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Tambah</span>
              </button>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex items-center justify-between pt-5 border-t border-stone-800">
            <button
              type="button"
              onClick={handleResetDefaults}
              className="text-stone-400 hover:text-rose-300 text-xs flex items-center gap-1 transition-colors cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset ke Template Awal</span>
            </button>

            <div className="flex gap-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-stone-300 hover:bg-stone-800 rounded-xl transition-colors cursor-pointer"
              >
                Batal
              </button>
              <button
                type="submit"
                className="px-6 py-2 bg-gradient-to-r from-rose-600 to-pink-600 text-white font-semibold rounded-xl hover:from-rose-500 hover:to-pink-500 transition-all shadow-md cursor-pointer flex items-center gap-1.5"
              >
                <Sparkles className="w-4 h-4" />
                <span>Terapkan Perubahan</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
