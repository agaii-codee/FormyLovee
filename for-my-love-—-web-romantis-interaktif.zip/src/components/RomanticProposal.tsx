import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { Heart, Sparkles, PartyPopper } from 'lucide-react';
import { romanticAudio } from '../utils/audio.ts';

interface RomanticProposalProps {
  partnerName: string;
  senderName: string;
}

export const RomanticProposal: React.FC<RomanticProposalProps> = ({
  partnerName,
  senderName,
}) => {
  const [hasAccepted, setHasAccepted] = useState(false);
  const [noPosition, setNoPosition] = useState({ x: 0, y: 0 });
  const [evadeCount, setEvadeCount] = useState(0);

  const handleHoverNo = () => {
    // Generate playful offset avoiding staying still
    const angle = Math.random() * Math.PI * 2;
    const distance = 80 + Math.random() * 80;
    const newX = Math.cos(angle) * distance;
    const newY = Math.sin(angle) * distance;

    setNoPosition({ x: newX, y: newY });
    setEvadeCount((prev) => prev + 1);
  };

  const handleYes = () => {
    setHasAccepted(true);
    romanticAudio.playCelebrationFanfare();

    // Trigger full multi-burst heart confetti shower
    const count = 200;
    const defaults = { origin: { y: 0.7 } };

    function fire(particleRatio: number, opts: confetti.Options) {
      confetti({
        ...defaults,
        ...opts,
        particleCount: Math.floor(count * particleRatio),
      });
    }

    fire(0.25, {
      spread: 26,
      startVelocity: 55,
      colors: ['#f43f5e', '#ec4899', '#fda4af'],
    });
    fire(0.2, {
      spread: 60,
      colors: ['#e11d48', '#fda4af', '#fbbf24'],
    });
    fire(0.35, {
      spread: 100,
      decay: 0.91,
      scalar: 0.9,
    });
    fire(0.1, {
      spread: 120,
      startVelocity: 25,
      decay: 0.92,
      colors: ['#ffffff', '#fb7185', '#ec4899'],
    });
    fire(0.1, {
      spread: 120,
      startVelocity: 45,
    });
  };

  return (
    <section id="pertanyaan" className="scroll-mt-24">
      <div className="relative rounded-3xl bg-gradient-to-b from-[#221327]/90 via-[#18111e]/90 to-[#0e0a12]/90 border border-rose-800/40 p-8 sm:p-14 text-center backdrop-blur-xl shadow-2xl overflow-hidden">
        {/* Ambient glow */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-rose-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-xl mx-auto">
          <div className="inline-flex items-center gap-1.5 text-xs uppercase tracking-widest text-rose-300 font-semibold mb-3">
            <Heart className="w-4 h-4 text-rose-400 fill-rose-400" />
            <span>Sebuah Pertanyaan Dari Hati</span>
          </div>

          <h2 className="text-3xl sm:text-4xl font-serif-romantic text-white font-normal leading-tight">
            Maukah Kamu Terus Berjalan Bersamaku, {partnerName}?
          </h2>

          <p className="text-sm sm:text-base text-stone-300 mt-3 font-light">
            Melewati setiap musim kehidupan, bergandengan tangan, dan merajut lebih banyak kisah bahagia berdua.
          </p>

          {!hasAccepted ? (
            <div className="mt-10 min-h-[140px] flex items-center justify-center relative">
              <div className="flex items-center justify-center gap-5">
                {/* YES BUTTON */}
                <button
                  onClick={handleYes}
                  className="px-8 py-3.5 text-sm sm:text-base font-bold text-white bg-gradient-to-r from-rose-600 via-pink-600 to-rose-600 rounded-full hover:scale-105 active:scale-95 transition-all shadow-xl shadow-rose-950/70 cursor-pointer flex items-center gap-2 group"
                >
                  <Sparkles className="w-4 h-4 text-amber-200 group-hover:rotate-12 transition-transform" />
                  <span>Iya, Tentu Saja! ❤️</span>
                </button>

                {/* PLAYFUL NO BUTTON */}
                <button
                  onMouseEnter={handleHoverNo}
                  onTouchStart={handleHoverNo}
                  onClick={handleHoverNo}
                  style={{
                    transform: `translate(${noPosition.x}px, ${noPosition.y}px)`,
                    transition: 'transform 0.15s cubic-bezier(0.16, 1, 0.3, 1)',
                  }}
                  className="px-6 py-3 text-xs sm:text-sm font-medium text-stone-400 bg-stone-900/80 hover:bg-stone-800 border border-stone-800 rounded-full cursor-pointer select-none"
                >
                  {evadeCount === 0
                    ? 'Nggak Dulu 😜'
                    : evadeCount === 1
                    ? 'Yakin Nggak? 🥺'
                    : evadeCount === 2
                    ? 'Tombolnya Kabur! 🏃'
                    : 'Pilih "Iya" Saja! 💕'}
                </button>
              </div>
            </div>
          ) : (
            <div className="mt-8 p-6 sm:p-8 rounded-2xl bg-gradient-to-br from-rose-950/70 via-stone-900/90 to-rose-950/60 border border-rose-500/40 animate-fade-in shadow-2xl">
              <div className="w-14 h-14 mx-auto rounded-full bg-rose-600/20 border border-rose-400 flex items-center justify-center mb-4 text-rose-300">
                <PartyPopper className="w-8 h-8 text-rose-300 animate-bounce" />
              </div>

              <h3 className="font-handwriting text-3xl sm:text-4xl text-rose-200 font-bold mb-2">
                Terima kasih, Sayangku! 💖
              </h3>

              <p className="text-sm sm:text-base text-stone-200 leading-relaxed font-light">
                Aku berjanji akan selalu menjaga senyum manismu dan mencintaimu di setiap hembusan nafasku.
              </p>

              <div className="mt-5 text-xs text-rose-300/80 border-t border-rose-900/40 pt-3">
                Janji setia dari <span className="font-semibold text-rose-200">{senderName}</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};
