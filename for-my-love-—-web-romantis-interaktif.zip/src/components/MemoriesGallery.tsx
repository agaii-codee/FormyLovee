import React, { useState } from 'react';
import { Camera, Plus, X, MapPin, Calendar, Heart } from 'lucide-react';
import { MemoryItem } from '../types.ts';
import { romanticAudio } from '../utils/audio.ts';

interface MemoriesGalleryProps {
  memories: MemoryItem[];
  onAddMemory: (item: MemoryItem) => void;
  onRemoveMemory: (id: string) => void;
}

export const MemoriesGallery: React.FC<MemoriesGalleryProps> = ({
  memories,
  onAddMemory,
  onRemoveMemory,
}) => {
  const [selectedMemory, setSelectedMemory] = useState<MemoryItem | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // New Memory Form State
  const [newTitle, setNewTitle] = useState('');
  const [newDate, setNewDate] = useState('');
  const [newLocation, setNewLocation] = useState('');
  const [newCaption, setNewCaption] = useState('');
  const [newImageUrl, setNewImageUrl] = useState('');

  const handleOpenPhoto = (item: MemoryItem) => {
    romanticAudio.playHeartChime();
    setSelectedMemory(item);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setNewImageUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveMemory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const item: MemoryItem = {
      id: `mem-${Date.now()}`,
      title: newTitle,
      date: newDate || new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' }),
      location: newLocation || 'Tempat Spesial',
      caption: newCaption || 'Sebuah momen manis yang takkan pernah terlupakan.',
      imageUrl: newImageUrl || memories[0]?.imageUrl || '/src/assets/images/romantic_polaroid_sunset_1793109356796.jpg',
    };

    onAddMemory(item);
    romanticAudio.playHeartChime();
    setIsAddModalOpen(false);

    // Reset form
    setNewTitle('');
    setNewDate('');
    setNewLocation('');
    setNewCaption('');
    setNewImageUrl('');
  };

  return (
    <section id="kenangan" className="scroll-mt-24">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
        <div>
          <div className="flex items-center gap-2 text-rose-300 text-xs font-semibold uppercase tracking-wider mb-1.5">
            <Camera className="w-4 h-4 text-rose-400" />
            <span>Album Kenangan Abadi</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-serif-romantic text-white">
            Momen-Momen Manis Bersamamu
          </h2>
        </div>

        <button
          onClick={() => setIsAddModalOpen(true)}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-rose-200 bg-rose-950/60 hover:bg-rose-900 border border-rose-800/40 rounded-full transition-colors cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4 text-rose-300" />
          <span>Tambah Foto Kenangan</span>
        </button>
      </div>

      {/* Polaroid Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
        {memories.map((item, index) => {
          // slight alternating polaroid rotation
          const rotDeg = index % 3 === 0 ? '-rotate-1' : index % 3 === 1 ? 'rotate-1' : '-rotate-0.5';

          return (
            <div
              key={item.id}
              onClick={() => handleOpenPhoto(item)}
              className={`group bg-[#17121b] border border-rose-900/30 rounded-2xl p-4 cursor-pointer transition-all duration-300 hover:scale-103 hover:shadow-2xl hover:shadow-rose-950/60 hover:border-rose-500/50 ${rotDeg}`}
            >
              {/* Photo Box with resilient fallback */}
              <div className="relative aspect-4/3 w-full rounded-xl overflow-hidden bg-stone-900 border border-white/5 mb-3">
                <img
                  src={item.imageUrl}
                  alt={item.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover object-top transition-transform duration-500 group-hover:scale-108"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = '/assets/aistudio/IMG-20260905-WA0038_40c95b50.jpg';
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-3">
                  <span className="text-xs text-rose-200 font-medium flex items-center gap-1">
                    <Heart className="w-3.5 h-3.5 fill-rose-400 text-rose-400" />
                    <span>Lihat cerita selengkapnya</span>
                  </span>
                </div>
              </div>

              {/* Polaroid Caption */}
              <div>
                <h3 className="font-serif-romantic text-lg text-white font-medium group-hover:text-rose-200 transition-colors">
                  {item.title}
                </h3>
                <div className="flex items-center gap-2 text-xs text-stone-400 mt-1">
                  <span>{item.date}</span>
                  {item.location && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-rose-400" />
                        <span>{item.location}</span>
                      </span>
                    </>
                  )}
                </div>
                <p className="font-handwriting text-xl text-rose-200/95 mt-2.5 leading-relaxed">
                  "{item.caption}"
                </p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Memory Detail Modal */}
      {selectedMemory && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
          <div className="relative max-w-xl w-full bg-[#18121d] border border-rose-900/40 rounded-3xl p-6 sm:p-8 shadow-2xl shadow-rose-950/80">
            <button
              onClick={() => setSelectedMemory(null)}
              className="absolute top-4 right-4 p-2 text-stone-400 hover:text-white rounded-full bg-stone-900/60 hover:bg-stone-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="aspect-4/3 w-full rounded-2xl overflow-hidden bg-stone-950 mb-5 border border-rose-900/30">
              <img
                src={selectedMemory.imageUrl}
                alt={selectedMemory.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>

            <div className="flex items-center gap-2 text-xs text-rose-300 mb-1.5">
              <Calendar className="w-3.5 h-3.5" />
              <span>{selectedMemory.date}</span>
              {selectedMemory.location && (
                <>
                  <span aria-hidden="true">·</span>
                  <MapPin className="w-3.5 h-3.5" />
                  <span>{selectedMemory.location}</span>
                </>
              )}
            </div>

            <h3 className="text-2xl font-serif-romantic text-white font-medium mb-3">
              {selectedMemory.title}
            </h3>

            <p className="font-handwriting text-2xl text-rose-200 leading-snug bg-rose-950/20 p-4 rounded-xl border border-rose-900/20">
              "{selectedMemory.caption}"
            </p>

            <div className="mt-6 flex justify-between items-center pt-4 border-t border-stone-800">
              <span className="text-xs text-stone-400">Tersimpan abadi di memori</span>
              {memories.length > 1 && (
                <button
                  onClick={() => {
                    onRemoveMemory(selectedMemory.id);
                    setSelectedMemory(null);
                  }}
                  className="text-xs text-rose-400 hover:text-rose-300 transition-colors cursor-pointer"
                >
                  Hapus Kenangan Ini
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Add Memory Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
          <div className="relative max-w-md w-full bg-[#18121d] border border-rose-900/40 rounded-3xl p-6 shadow-2xl">
            <button
              onClick={() => setIsAddModalOpen(false)}
              className="absolute top-4 right-4 p-1.5 text-stone-400 hover:text-white rounded-full bg-stone-900/60 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-xl font-serif-romantic text-white mb-4">
              Tambah Foto Kenangan Baru
            </h3>

            <form onSubmit={handleSaveMemory} className="space-y-4 text-xs">
              <div>
                <label className="block text-stone-300 font-medium mb-1">Judul Momen</label>
                <input
                  type="text"
                  required
                  placeholder="Misal: Jalan Berdua di Taman..."
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-stone-900/90 border border-stone-800 text-stone-100 focus:border-rose-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-stone-300 font-medium mb-1">Tanggal</label>
                  <input
                    type="text"
                    placeholder="Misal: 14 Februari 2024"
                    value={newDate}
                    onChange={(e) => setNewDate(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-stone-900/90 border border-stone-800 text-stone-100 focus:border-rose-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-stone-300 font-medium mb-1">Lokasi</label>
                  <input
                    type="text"
                    placeholder="Misal: Pantai Kuta"
                    value={newLocation}
                    onChange={(e) => setNewLocation(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-stone-900/90 border border-stone-800 text-stone-100 focus:border-rose-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-stone-300 font-medium mb-1">Pilih File Foto atau Masukkan URL Foto</label>
                <div className="space-y-2">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="w-full text-stone-400 file:mr-3 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-rose-950 file:text-rose-300 hover:file:bg-rose-900 cursor-pointer"
                  />
                  <input
                    type="url"
                    placeholder="Atau tempel URL gambar di sini..."
                    value={newImageUrl}
                    onChange={(e) => setNewImageUrl(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl bg-stone-900/90 border border-stone-800 text-stone-100 focus:border-rose-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-stone-300 font-medium mb-1">Catatan Cinta / Caption</label>
                <textarea
                  rows={3}
                  placeholder="Tuliskan cerita manis di balik foto ini..."
                  value={newCaption}
                  onChange={(e) => setNewCaption(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-stone-900/90 border border-stone-800 text-stone-100 focus:border-rose-500 focus:outline-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 text-stone-300 hover:bg-stone-800 rounded-xl transition-colors cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-gradient-to-r from-rose-600 to-pink-600 text-white font-semibold rounded-xl hover:from-rose-500 hover:to-pink-500 transition-all cursor-pointer shadow-md"
                >
                  Simpan Kenangan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </section>
  );
};
