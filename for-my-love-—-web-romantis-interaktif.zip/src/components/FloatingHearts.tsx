import React, { useEffect, useState } from 'react';

interface Particle {
  id: number;
  symbol: string;
  left: number;
  size: number;
  duration: number;
  delay: number;
}

const ICONS = ['❤️', '💖', '💕', '✨', '🌸', '💐', '💌', '🤍'];

export const FloatingHearts: React.FC = () => {
  const [particles, setParticles] = useState<Particle[]>([]);

  useEffect(() => {
    // Generate initial set of ambient particles
    const initial: Particle[] = Array.from({ length: 18 }).map((_, i) => ({
      id: i,
      symbol: ICONS[Math.floor(Math.random() * ICONS.length)],
      left: Math.random() * 96,
      size: Math.random() * 14 + 14,
      duration: Math.random() * 8 + 6,
      delay: Math.random() * 5,
    }));
    setParticles(initial);

    // Occasionally add a new rising particle
    const interval = setInterval(() => {
      setParticles(prev => {
        const nextId = Date.now() + Math.random();
        const fresh: Particle = {
          id: nextId,
          symbol: ICONS[Math.floor(Math.random() * ICONS.length)],
          left: Math.random() * 96,
          size: Math.random() * 16 + 14,
          duration: Math.random() * 9 + 6,
          delay: 0,
        };
        // Keep array size bounded
        return [...prev.slice(-24), fresh];
      });
    }, 2500);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {particles.map(p => (
        <span
          key={p.id}
          className="floating-heart select-none"
          style={{
            left: `${p.left}%`,
            bottom: '-40px',
            fontSize: `${p.size}px`,
            animationDuration: `${p.duration}s`,
            animationDelay: `${p.delay}s`,
          }}
        >
          {p.symbol}
        </span>
      ))}
    </div>
  );
};
