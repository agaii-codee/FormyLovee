import React, { useState, useEffect } from 'react';
import { Volume2, VolumeX, Play, Pause, Music, Sparkles } from 'lucide-react';
import { romanticAudio } from '../utils/audio.ts';

interface MusicPlayerBarProps {
  songTitle: string;
}

export const MusicPlayerBar: React.FC<MusicPlayerBarProps> = ({ songTitle }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState(75);
  const [isMuted, setIsMuted] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);

  useEffect(() => {
    // Subscribe to real-time audio state
    const unsubscribe = romanticAudio.subscribe((state) => {
      setIsPlaying(state);
    });
    return unsubscribe;
  }, []);

  const handleTogglePlay = () => {
    romanticAudio.toggle();
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = Number(e.target.value);
    setVolume(val);
    if (val === 0) {
      setIsMuted(true);
      romanticAudio.setVolume(0);
    } else {
      setIsMuted(false);
      romanticAudio.setVolume(val / 100);
    }
  };

  const handleToggleMute = () => {
    if (isMuted) {
      setIsMuted(false);
      romanticAudio.setVolume(volume / 100);
    } else {
      setIsMuted(true);
      romanticAudio.setVolume(0);
    }
  };

  return (
    <div className="fixed bottom-5 right-5 z-40 flex items-center">
      <div className="bg-[#18111d]/90 border border-rose-900/40 rounded-full px-4 py-2.5 backdrop-blur-xl shadow-2xl flex items-center gap-3">
        {/* Play/Pause Button */}
        <button
          onClick={handleTogglePlay}
          className="w-9 h-9 rounded-full bg-gradient-to-r from-rose-600 to-pink-600 flex items-center justify-center text-white shadow-md shadow-rose-950/60 hover:scale-105 active:scale-95 transition-all cursor-pointer"
          title={isPlaying ? 'Jeda Musik' : 'Putar Musik Romantis'}
        >
          {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
        </button>

        {/* Music Title & Sound Wave */}
        <div
          onClick={() => setIsExpanded(!isExpanded)}
          className="cursor-pointer select-none flex items-center gap-2.5 pr-1"
        >
          <div className="flex flex-col">
            <span className="text-[11px] text-rose-300 font-medium flex items-center gap-1">
              <Music className="w-3 h-3 text-rose-400" />
              <span className="truncate max-w-[160px] sm:max-w-[220px] font-semibold">{songTitle}</span>
            </span>
            <span className="text-[10px] text-stone-400">
              {isPlaying ? 'Sedang Memutar Melodi' : 'Ketuk untuk memutar musik'}
            </span>
          </div>

          {/* Animated visualizer bars */}
          {isPlaying && (
            <div className="flex items-end gap-0.5 h-4 px-1">
              <div className="w-1 bg-rose-400 rounded-full animate-pulse h-3" />
              <div className="w-1 bg-pink-400 rounded-full animate-pulse h-4 delay-75" />
              <div className="w-1 bg-rose-300 rounded-full animate-pulse h-2 delay-150" />
            </div>
          )}
        </div>

        {/* Volume & Sound Effect Actions */}
        <div className="hidden sm:flex items-center gap-2 pl-2 border-l border-stone-800">
          <button
            onClick={handleToggleMute}
            className="text-stone-400 hover:text-rose-200 transition-colors p-1 cursor-pointer"
          >
            {isMuted || volume === 0 ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>

          <input
            type="range"
            min="0"
            max="100"
            value={isMuted ? 0 : volume}
            onChange={handleVolumeChange}
            className="w-16 h-1 bg-stone-800 rounded-lg appearance-none cursor-pointer accent-rose-500"
          />

          <button
            onClick={() => romanticAudio.playHeartChime()}
            title="Denting Cinta"
            className="p-1 text-rose-400 hover:text-rose-200 transition-colors cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
