import React, { useState, useEffect } from 'react';
import { CalendarHeart, Flame, Sparkles } from 'lucide-react';

interface RelationshipTimerProps {
  startDate: string;
  partnerName: string;
}

export const RelationshipTimer: React.FC<RelationshipTimerProps> = ({
  startDate,
  partnerName,
}) => {
  const [timeTogether, setTimeTogether] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
    totalSeconds: 0,
  });

  useEffect(() => {
    const calculateTime = () => {
      const start = new Date(startDate).getTime();
      const now = new Date().getTime();
      const diffMs = Math.max(0, now - start);
      const totalSeconds = Math.floor(diffMs / 1000);

      const days = Math.floor(totalSeconds / 86400);
      const hours = Math.floor((totalSeconds % 86400) / 3600);
      const minutes = Math.floor((totalSeconds % 3600) / 60);
      const seconds = totalSeconds % 60;

      setTimeTogether({ days, hours, minutes, seconds, totalSeconds });
    };

    calculateTime();
    const interval = setInterval(calculateTime, 1000);
    return () => clearInterval(interval);
  }, [startDate]);

  const dateObject = new Date(startDate);
  const formattedStartDate = isNaN(dateObject.getTime())
    ? startDate
    : dateObject.toLocaleDateString('id-ID', {
        day: 'numeric',
        month: 'long',
        year: 'numeric',
      });

  // Calculate milestone
  const milestones = [100, 365, 500, 730, 1000, 1500, 2000];
  const nextMilestone = milestones.find(m => m > timeTogether.days) || timeTogether.days + 100;
  const prevMilestone = [...milestones].reverse().find(m => m <= timeTogether.days) || 0;
  const milestoneProgress = Math.min(
    100,
    Math.max(
      0,
      Math.round(((timeTogether.days - prevMilestone) / (nextMilestone - prevMilestone)) * 100)
    )
  );

  return (
    <section id="perjalanan" className="scroll-mt-24">
      <div className="relative rounded-3xl bg-gradient-to-b from-stone-900/90 via-stone-900/60 to-stone-950/90 border border-rose-900/30 p-7 sm:p-10 backdrop-blur-xl shadow-2xl shadow-black/60 overflow-hidden">
        {/* Subtle romantic ambient lighting behind */}
        <div className="absolute -top-24 -left-24 w-72 h-72 bg-rose-600/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -right-24 w-72 h-72 bg-pink-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10">
          {/* Section Header */}
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-6 border-b border-stone-800/80">
            <div>
              <div className="flex items-center gap-2 text-xs uppercase tracking-wider text-rose-300 font-semibold mb-1.5">
                <CalendarHeart className="w-4 h-4 text-rose-400" />
                <span>Hari Bersama Kamu</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-serif-romantic text-white">
                Setiap Detik Bersamamu, {partnerName}
              </h2>
            </div>
            <div className="text-left sm:text-right text-xs text-stone-400">
              <span>Dimulai sejak</span>
              <p className="text-sm font-medium text-rose-200 mt-0.5">{formattedStartDate}</p>
            </div>
          </div>

          {/* 4-Box Ticking Timer */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 my-8">
            <div className="bg-stone-950/70 border border-rose-900/25 rounded-2xl p-5 text-center transition-transform hover:-translate-y-1">
              <span className="block text-4xl sm:text-5xl font-extrabold text-rose-200 tabular-nums">
                {timeTogether.days}
              </span>
              <span className="text-xs font-medium text-stone-400 uppercase tracking-widest mt-2 block">
                Hari
              </span>
            </div>

            <div className="bg-stone-950/70 border border-rose-900/25 rounded-2xl p-5 text-center transition-transform hover:-translate-y-1">
              <span className="block text-4xl sm:text-5xl font-extrabold text-rose-200 tabular-nums">
                {String(timeTogether.hours).padStart(2, '0')}
              </span>
              <span className="text-xs font-medium text-stone-400 uppercase tracking-widest mt-2 block">
                Jam
              </span>
            </div>

            <div className="bg-stone-950/70 border border-rose-900/25 rounded-2xl p-5 text-center transition-transform hover:-translate-y-1">
              <span className="block text-4xl sm:text-5xl font-extrabold text-rose-200 tabular-nums">
                {String(timeTogether.minutes).padStart(2, '0')}
              </span>
              <span className="text-xs font-medium text-stone-400 uppercase tracking-widest mt-2 block">
                Menit
              </span>
            </div>

            <div className="bg-stone-950/70 border border-rose-900/25 rounded-2xl p-5 text-center transition-transform hover:-translate-y-1">
              <span className="block text-4xl sm:text-5xl font-extrabold text-rose-400 tabular-nums">
                {String(timeTogether.seconds).padStart(2, '0')}
              </span>
              <span className="text-xs font-medium text-stone-400 uppercase tracking-widest mt-2 block">
                Detik
              </span>
            </div>
          </div>

          {/* Milestone Progress Bar */}
          <div className="bg-stone-950/50 border border-stone-800/80 rounded-2xl p-4 sm:p-5">
            <div className="flex items-center justify-between text-xs mb-2">
              <div className="flex items-center gap-1.5 text-rose-300 font-medium">
                <Flame className="w-3.5 h-3.5 text-rose-400" />
                <span>Menuju Milestone {nextMilestone} Hari</span>
              </div>
              <span className="text-stone-400 font-mono tabular-nums">
                Tersisa {Math.max(0, nextMilestone - timeTogether.days)} hari lagi
              </span>
            </div>
            <div className="w-full bg-stone-900 h-2.5 rounded-full overflow-hidden p-0.5">
              <div
                className="bg-gradient-to-r from-rose-500 via-pink-500 to-rose-400 h-full rounded-full transition-all duration-500"
                style={{ width: `${milestoneProgress}%` }}
              />
            </div>
            <p className="text-xs text-stone-400 mt-2.5 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-300 shrink-0" />
              <span>Sudah melewati {timeTogether.days} hari indah penuh canda, tawa, dan rasa sayang.</span>
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
