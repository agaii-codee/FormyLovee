import React, { useState } from 'react';
import { Heart, Sparkles, Shuffle, ListFilter } from 'lucide-react';
import { romanticAudio } from '../utils/audio.ts';

interface LoveReasonsJarProps {
  reasons: string[];
  partnerName: string;
}

export const LoveReasonsJar: React.FC<LoveReasonsJarProps> = ({
  reasons,
  partnerName,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipping, setIsFlipping] = useState(false);
  const [showAllModal, setShowAllModal] = useState(false);

  const handleNext = () => {
    setIsFlipping(true);
    romanticAudio.playHeartChime();
    setTimeout(() => {
      setCurrentIndex((prev) => (prev + 1) % reasons.length);
      setIsFlipping(false);
    }, 180);
  };

  const handleRandom = () => {
    setIsFlipping(true);
    romanticAudio.playHeartChime();
    setTimeout(() => {
      let rand = Math.floor(Math.random() * reasons.length);
      if (rand === currentIndex && reasons.length > 1) {
        rand = (rand + 1) % reasons.length;
      }
      setCurrentIndex(rand);
      setIsFlipping(false);
    }, 180);
  };

  return (
    <section id="alasan" className="scroll-mt-24">
      <div className="rounded-3xl bg-gradient-to-b from-stone-900/80 via-[#18121d] to-stone-950/80 border border-rose-900/30 p-7 sm:p-10 backdrop-blur-xl shadow-2xl">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-6 border-b border-stone-800">
          <div>
            <div className="flex items-center gap-2 text-rose-300 text-xs font-semibold uppercase tracking-wider mb-1.5">
              <Heart className="w-4 h-4 text-rose-400 fill-rose-400" />
              <span>Toples Alasan Cinta</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-serif-romantic text-white">
              Kenapa Aku Begitu Mencintaimu?
            </h2>
          </div>

          <div className="flex items-center gap-2 text-xs text-stone-400">
            <span>Alasan ke-{currentIndex + 1} dari {reasons.length}</span>
            <span aria-hidden="true">·</span>
            <button
              onClick={() => setShowAllModal(true)}
              className="text-rose-300 hover:text-rose-100 flex items-center gap-1 cursor-pointer transition-colors"
            >
              <ListFilter className="w-3.5 h-3.5" />
              <span>Buka Daftar Semua</span>
            </button>
          </div>
        </div>

        {/* Central Love Card */}
        <div className="my-8 flex justify-center">
          <div
            className={`relative max-w-2xl w-full bg-gradient-to-br from-rose-950/40 via-stone-900/90 to-rose-950/30 border border-rose-800/40 rounded-3xl p-8 sm:p-12 text-center shadow-xl shadow-black/50 transition-all duration-300 ${
              isFlipping ? 'scale-95 opacity-50' : 'scale-100 opacity-100'
            }`}
          >
            <div className="w-12 h-12 mx-auto rounded-full bg-rose-950 border border-rose-700/60 flex items-center justify-center mb-5 text-rose-300">
              <Sparkles className="w-6 h-6 text-rose-400" />
            </div>

            <p className="font-serif-romantic text-xl sm:text-2xl text-rose-100 leading-relaxed italic">
              "{reasons[currentIndex]}"
            </p>

            <span className="font-handwriting text-2xl text-rose-400 mt-4 block">
              — Selalu ada untukmu, {partnerName}
            </span>
          </div>
        </div>

        {/* Control Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-3">
          <button
            onClick={handleNext}
            className="px-6 py-2.5 text-xs font-semibold text-white bg-gradient-to-r from-rose-600 to-pink-600 rounded-full hover:from-rose-500 hover:to-pink-500 transition-all shadow-lg shadow-rose-950/50 cursor-pointer flex items-center gap-2"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Alasan Berikutnya</span>
          </button>

          <button
            onClick={handleRandom}
            className="px-5 py-2.5 text-xs font-medium text-rose-200 bg-stone-900/80 hover:bg-stone-800 border border-rose-900/40 rounded-full transition-colors cursor-pointer flex items-center gap-2"
          >
            <Shuffle className="w-3.5 h-3.5" />
            <span>Acak Alasan</span>
          </button>
        </div>
      </div>

      {/* Show All Modal */}
      {showAllModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="relative max-w-xl w-full max-h-[80vh] overflow-y-auto bg-[#18121d] border border-rose-900/40 rounded-3xl p-6 sm:p-8 shadow-2xl">
            <div className="flex justify-between items-center mb-6 pb-3 border-b border-stone-800">
              <h3 className="text-xl font-serif-romantic text-white">
                Semua Alasan Mencintaimu ({reasons.length})
              </h3>
              <button
                onClick={() => setShowAllModal(false)}
                className="text-stone-400 hover:text-white text-xs px-3 py-1 rounded-lg bg-stone-900 cursor-pointer"
              >
                Tutup
              </button>
            </div>

            <div className="space-y-3">
              {reasons.map((r, i) => (
                <div
                  key={i}
                  className="p-4 rounded-xl bg-stone-900/60 border border-rose-950/80 hover:border-rose-800/60 transition-colors flex items-start gap-3"
                >
                  <span className="w-6 h-6 rounded-full bg-rose-950/80 border border-rose-800/40 text-rose-300 text-xs flex items-center justify-center shrink-0 mt-0.5">
                    {i + 1}
                  </span>
                  <p className="text-sm text-stone-200 leading-relaxed">{r}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
