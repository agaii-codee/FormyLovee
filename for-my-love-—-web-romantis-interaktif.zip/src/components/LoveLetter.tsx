import React, { useState, useEffect } from 'react';
import { Feather, HeartHandshake, Play, Eye } from 'lucide-react';
import { romanticAudio } from '../utils/audio.ts';

interface LoveLetterProps {
  headline: string;
  body: string;
  senderName: string;
  partnerName: string;
}

export const LoveLetter: React.FC<LoveLetterProps> = ({
  headline,
  body,
  senderName,
  partnerName,
}) => {
  const [isTypewriterActive, setIsTypewriterActive] = useState(false);
  const [typedLength, setTypedLength] = useState(body.length);

  // Typewriter effect controller
  useEffect(() => {
    if (!isTypewriterActive) {
      setTypedLength(body.length);
      return;
    }

    setTypedLength(0);
    let current = 0;
    const interval = setInterval(() => {
      current += 2;
      if (current >= body.length) {
        setTypedLength(body.length);
        setIsTypewriterActive(false);
        clearInterval(interval);
      } else {
        setTypedLength(current);
      }
    }, 28);

    return () => clearInterval(interval);
  }, [isTypewriterActive, body]);

  const handleStartTypewriter = () => {
    romanticAudio.playHeartChime();
    setIsTypewriterActive(true);
  };

  const paragraphs = body.slice(0, typedLength).split('\n\n');

  return (
    <section id="surat" className="scroll-mt-24">
      <div className="relative rounded-3xl bg-[#19131d]/90 border border-rose-900/35 p-7 sm:p-12 backdrop-blur-xl shadow-2xl shadow-black/70">
        {/* Subtle decorative watermark/seal */}
        <div className="flex items-center justify-between pb-6 border-b border-rose-950/70">
          <div className="flex items-center gap-2 text-rose-300 text-xs font-semibold uppercase tracking-wider">
            <Feather className="w-4 h-4 text-rose-400" />
            <span>Surat Terbuka Dari Relung Hati</span>
          </div>

          {/* Toggle Typewriter effect */}
          <button
            onClick={isTypewriterActive ? () => setIsTypewriterActive(false) : handleStartTypewriter}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium text-rose-300 bg-rose-950/40 hover:bg-rose-950 border border-rose-800/40 transition-colors cursor-pointer"
          >
            {isTypewriterActive ? (
              <>
                <Eye className="w-3.5 h-3.5" />
                <span>Lihat Semua Teks</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5" />
                <span>Ketik Ulang Otomatis</span>
              </>
            )}
          </button>
        </div>

        {/* Letter Title */}
        <div className="my-8">
          <p className="text-xs text-rose-400/90 font-medium uppercase tracking-widest mb-1.5">
            Didedikasikan untuk: {partnerName}
          </p>
          <h2 className="text-2xl sm:text-4xl font-serif-romantic text-rose-100 font-normal leading-snug">
            {headline}
          </h2>
        </div>

        {/* Letter Body */}
        <div className="space-y-5 text-stone-200 text-base sm:text-lg leading-relaxed font-sans font-light">
          {paragraphs.map((p, idx) => (
            <p key={idx} className="first-letter:text-2xl first-letter:font-serif-romantic first-letter:text-rose-300">
              {p}
            </p>
          ))}
          {isTypewriterActive && typedLength < body.length && (
            <span className="inline-block w-2 h-5 bg-rose-400 animate-pulse ml-1 align-middle" />
          )}
        </div>

        {/* Signature & Wax Seal */}
        <div className="mt-12 pt-8 border-t border-rose-950/70 flex flex-col sm:flex-row sm:items-end justify-between gap-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-rose-950 border border-rose-800/60 flex items-center justify-center text-rose-300">
              <HeartHandshake className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs text-stone-400">Selalu & Selamanya</p>
              <p className="text-sm font-medium text-rose-200">Untuk Satu Jiwa yang Terpilih</p>
            </div>
          </div>

          <div className="text-left sm:text-right">
            <span className="text-xs text-stone-400 block mb-1">Tertanda dengan penuh cinta,</span>
            <span className="font-handwriting text-3xl sm:text-4xl text-rose-300 font-bold block">
              {senderName}
            </span>
          </div>
        </div>
      </div>
    </section>
  );
};
