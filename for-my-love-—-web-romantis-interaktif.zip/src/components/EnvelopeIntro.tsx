import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { romanticAudio } from '../utils/audio.ts';
import { Mail, Sparkles, Heart } from 'lucide-react';

interface EnvelopeIntroProps {
  partnerName: string;
  senderName: string;
  onOpen: () => void;
}

export const EnvelopeIntro: React.FC<EnvelopeIntroProps> = ({
  partnerName,
  senderName,
  onOpen,
}) => {
  const [isOpening, setIsOpening] = useState(false);

  const handleEnvelopeClick = () => {
    if (isOpening) return;
    setIsOpening(true);

    // Start background music immediately upon user gesture
    romanticAudio.play();
    romanticAudio.playHeartChime();

    // Heart explosion confetti
    try {
      confetti({
        particleCount: 70,
        spread: 90,
        origin: { y: 0.6 },
        colors: ['#f43f5e', '#ec4899', '#fda4af', '#fecdd3', '#fbbf24'],
        shapes: ['circle'],
        scalar: 1.2,
      });
    } catch {
      // ignore
    }

    setTimeout(() => {
      onOpen();
    }, 850);
  };

  return (
    <div
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center p-6 bg-radial from-[#2a132e] via-[#140c18] to-[#08050a] transition-all duration-700 ${
        isOpening ? 'opacity-0 scale-105 pointer-events-none' : 'opacity-100 scale-100'
      }`}
    >
      <div className="text-center mb-8 max-w-md">
        <div className="inline-flex items-center gap-1.5 text-xs uppercase tracking-widest text-rose-300 font-medium mb-3">
          <Sparkles className="w-3.5 h-3.5 text-rose-400" />
          <span>Sebuah Pesan Rahasia</span>
        </div>
        <h1 className="text-3xl md:text-4xl font-serif-romantic text-white font-normal mb-2">
          Untuk {partnerName}
        </h1>
        <p className="text-sm text-stone-300">
          Ada sepucuk surat tulus yang ditulis penuh rasa cinta oleh <span className="text-rose-300 font-medium">{senderName}</span>
        </p>
      </div>

      {/* Interactive Envelope with 3D-like wax seal */}
      <div
        onClick={handleEnvelopeClick}
        className="group relative w-72 sm:w-84 h-52 bg-gradient-to-br from-rose-950 via-rose-900 to-rose-950 rounded-2xl cursor-pointer shadow-2xl shadow-rose-950/70 border border-rose-700/30 flex items-center justify-center transition-all duration-300 hover:scale-105 hover:-translate-y-1.5"
      >
        {/* Envelope Flap visual lines */}
        <div className="absolute inset-x-0 top-0 h-28 border-b border-rose-500/20 bg-gradient-to-b from-rose-800/40 to-transparent clip-path-triangle pointer-events-none rounded-t-2xl" />

        {/* Floating Heart particles around envelope */}
        <div className="absolute -top-3 -right-3 w-8 h-8 rounded-full bg-rose-500/20 backdrop-blur-sm border border-rose-400/40 flex items-center justify-center animate-bounce">
          <Heart className="w-4 h-4 text-rose-300 fill-rose-300" />
        </div>

        {/* Center Wax Seal Button */}
        <div className="relative z-10 flex flex-col items-center">
          <div className="w-18 h-18 rounded-full bg-gradient-to-br from-rose-600 to-rose-800 border-2 border-rose-300/80 shadow-lg shadow-rose-950/80 flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
            <Mail className="w-8 h-8 text-rose-100 group-hover:rotate-6 transition-transform" />
          </div>
          <span className="mt-3 text-xs tracking-wider font-semibold text-rose-200 uppercase bg-rose-950/80 px-3 py-1 rounded-full border border-rose-800/60 shadow-sm">
            Ketuk Untuk Membuka
          </span>
        </div>
      </div>

      <div className="mt-8 flex items-center gap-2 text-xs text-stone-400">
        <Sparkles className="w-3.5 h-3.5 text-rose-400" />
        <span>Gunakan headphone atau nyalakan suara untuk pengalaman terbaik</span>
      </div>
    </div>
  );
};
