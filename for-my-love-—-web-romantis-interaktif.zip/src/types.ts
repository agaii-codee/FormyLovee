export interface MemoryItem {
  id: string;
  title: string;
  date: string;
  imageUrl: string;
  caption: string;
  location?: string;
}

export interface RomanticData {
  partnerName: string;
  senderName: string;
  startDate: string; // ISO string like '2024-02-14T00:00:00'
  relationshipTitle: string;
  letterHeadline: string;
  letterBody: string;
  customQuote: string;
  reasons: string[];
  memories: MemoryItem[];
  songTitle: string;
}
